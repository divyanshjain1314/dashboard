 const config = {
    appurl : "/admin/dashboard"
}
export default config